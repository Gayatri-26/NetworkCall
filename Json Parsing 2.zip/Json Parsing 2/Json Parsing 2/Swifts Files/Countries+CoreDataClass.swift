//
//  Countries+CoreDataClass.swift
//  Json Parsing 2
//
//  Created by Mac on 09/09/20.
//  Copyright © 2020 Mac. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Countries)
public class Countries: NSManagedObject {

}
