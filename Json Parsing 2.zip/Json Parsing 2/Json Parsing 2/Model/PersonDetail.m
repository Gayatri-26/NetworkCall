//
//  PersonDetail.m
//  Json Parsing 2
//
//  Created by Mac on 04/09/20.
//  Copyright © 2020 Mac. All rights reserved.
//

#import "PersonDetail.h"

@implementation PersonDetail

@synthesize Pid, Pname, Pemail, Paddress, Pgender;

@end
