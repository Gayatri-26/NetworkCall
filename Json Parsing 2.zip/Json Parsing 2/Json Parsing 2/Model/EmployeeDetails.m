//
//  EmployeeDetails.m
//  Json Parsing 2
//
//  Created by Mac on 28/08/20.
//  Copyright © 2020 Mac. All rights reserved.
//

#import "EmployeeDetails.h"

@implementation EmployeeDetails

@synthesize EmpId, Name, Salary, Age;

@end
