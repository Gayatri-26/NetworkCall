//
//  PersonViewCell.h
//  Json Parsing 2
//
//  Created by Mac on 27/08/20.
//  Copyright © 2020 Mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PersonViewCell : UITableViewCell

@property (strong, nonatomic)  UILabel *Pid;
@property (strong, nonatomic)  UILabel *Pname;
@property (strong, nonatomic)  UILabel *Paddress;
@property (strong, nonatomic)  UILabel *Pemail;
@property (strong, nonatomic)  UILabel *Pgender;
@property (strong, nonatomic)  UIView *view;

@end
