//
//  EmployeeDetailsCell.h
//  Json Parsing 2
//
//  Created by Mac on 27/08/20.
//  Copyright © 2020 Mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EmployeeDetailsCell : UITableViewCell

@property (strong, nonatomic)  UILabel *LblId;
@property (strong, nonatomic)  UILabel *LblName;
@property (strong, nonatomic)  UILabel *LblSalary;
@property (strong, nonatomic)  UILabel *LblAge;


@end
